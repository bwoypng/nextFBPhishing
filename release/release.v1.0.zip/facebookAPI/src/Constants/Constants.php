<?php

namespace facebookAPI\Constants;

class Constants {

    const FacebookName = "MessengerLite";
    const facebook_version = "71.0.1.19.242";
    const facebook_package_name = "com.facebook.mlite";
    const facebook_package_number = "182721499";
    const facebook_version_release = "5.1.1";

    const facebook_api_link = 'b-api.facebook.com';
}
